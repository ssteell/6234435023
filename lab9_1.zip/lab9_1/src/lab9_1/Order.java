package lab9_1;

import java.util.ArrayList;

public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p;
    public Order(Customer customer){
        this.p = new ArrayList<>();
        c = customer;
        cntOrder++;
    }
    public void addPizza(Pizza pizza){
        p.add(pizza);
    }
    public String getOrderDetail(){
        id = cntOrder;
        String order = ""+p.get(0);
        for(int i = 1;i < p.size();i++)order += ("\n"+p.get(i));
        return "Order id : "+id+"\n"+c.toString()+"\n"+order+"\nTotal prices : "+p.size()+"\nTotal cost : "+this.calculatePayment();
    }    
    public double calculatePayment(){
        double price = 0;
        if(c instanceof GoldCustomer){
            for(int i = 0;i < p.size();i++){
                GoldCustomer c2 = (GoldCustomer) c;
                price += (p.get(i)).getPrice() - (((c2.getDiscount()/100))*(p.get(i)).getPrice());
            }
        }
        else{
            for(int i = 0;i < p.size();i++){
                price += (p.get(i)).getPrice();
            }
        }
        return price;
    }
}
