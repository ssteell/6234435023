package lab10_2;

import java.util.ArrayList;

public class BusTester {

    public static void main(String[] args) {
        ArrayList<Object> arr = new ArrayList<Object>();
        Hybrid H = new Hybrid(45,1200000,600,150,1);
        arr.add(H);
        CNGBus C = new CNGBus(50,100000,200,2);
        arr.add(C);
        for(int i = 0;i < arr.size();i++){
            if(arr.get(i)instanceof CNGBus){
                CNGBus c = (CNGBus)arr.get(i);
                System.out.println("ID: "+(i+1)+"\nEmission Tier: "+C.getEmissinoTier()+"\nAccel: "+C.getAccel()); 
            }
            else{
                Hybrid h = (Hybrid)arr.get(i);
                System.out.println("ID: "+(i+1)+"\nEmission Tier: "+H.getEmissinoTier()+"\nAccel: "+H.getAccel());
            }
            
        }
    }
    
}
