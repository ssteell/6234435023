package lab10_2;

public class Hybrid extends Bus implements LiquidFuel,Electric {
    private double voltage, range;
    private int emissinoTier;
    public Hybrid(int capacity, double cost , double voltage , double range , int emissinoTier) {
        super(capacity, cost);
        if(voltage < LOW_VOLTAGE)this.voltage = LOW_VOLTAGE;
        else if(voltage < HIGH_VOLTAGE)this.voltage = voltage;
        else this.voltage = HIGH_VOLTAGE;
        this.range = range;
        this.emissinoTier = emissinoTier;
    } 
    @Override
    public double getAccel() {
        return 4.0;
    }

    @Override
    public double getRange() {
        return range;
    }

    @Override
    public int getEmissinoTier() {
        return emissinoTier;
    }

    @Override
    public double getVoltage() {
        return voltage;
    }
}
