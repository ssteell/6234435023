package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue {
    ArrayList <Object> music = new ArrayList <Object>();
    @Override
    public void enqueue(Object o) {
        music.add(o);
        System.out.println(o+" is added in queue");
    }

    @Override
    public void dequeue() {
        System.out.println("Now playing "+music.get(0)); 
        music.remove(0);    
    }

    
}
