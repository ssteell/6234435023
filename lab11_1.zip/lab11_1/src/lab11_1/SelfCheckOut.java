package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue {
    ArrayList <Object> piece = new ArrayList <Object>();
    ArrayList <Double> price = new ArrayList <Double>();
    private double total;
    @Override
    public void enqueue(Object o) {
        Product i = (Product)o;
        piece.add(i.getname());
        price.add(i.getPrice());
        System.out.println(i.getname()+" is added in queue");   
    }

    @Override
    public void dequeue() {
        piece.remove(0);
        total += price.get(0);
        price.remove(0);
    }
    public double getAmount(){
        return total;
    }
}
