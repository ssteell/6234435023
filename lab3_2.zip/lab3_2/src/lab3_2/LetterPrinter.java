/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author usci
 */
public class LetterPrinter {
    public static void main(String[] args) {
        Letter jade = new Letter("Jade","Clarissa");
        jade.addLine("We must find Simon quickly.\nHe might be in danger.");
        System.out.printf(jade.getText());
    }
}
