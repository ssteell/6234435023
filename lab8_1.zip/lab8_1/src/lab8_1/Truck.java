package lab8_1;

public class Truck extends Car{
    private double M_weight,weight;

    public Truck(double gas, double efficiency,double max,double weight) {
        super(gas, efficiency);
        M_weight = max;
        if(M_weight < weight)this.weight = weight;
        else this.weight = M_weight;
    }
    @Override
    public void drive(double distance){
        if((super.getGas()-(distance/super.getEfficiency())) <= 0){
            System.out.println("you cannot drive too far,please add gas");
        }
        else{
            if(weight < 1)super.setGas(super.getGas()-(distance/super.getEfficiency()));
            else if(weight <= 10)super.setGas(super.getGas()-((distance/super.getEfficiency())*1.1));
            else if(weight <= 20)super.setGas(super.getGas()-((distance/super.getEfficiency())*1.2));
            else if(weight > 20)super.setGas(super.getGas()-((distance/super.getEfficiency())*1.3));
        }
        
    }
    
}
