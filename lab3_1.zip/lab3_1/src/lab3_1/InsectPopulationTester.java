/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_1;

/**
 *
 * @author usci
 */
public class InsectPopulationTester {
    public static void main(String[] args) {
        InsectPopulation num = new InsectPopulation(10);
        num.breed();
        num.spray();
        System.out.println("Number of insects: "+(float)num.getNumInsect());
        num.breed();
        num.spray();
        System.out.println("Number of insects: "+(float)num.getNumInsect());
        num.breed();
        num.spray();
        System.out.println("Number of insects: "+(float)num.getNumInsect());
        
    }
}
