/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;

/**
 *
 * @author amsteel
 */
public class Zeller {
    private int DayOfMonth,month,year;
    enum Day{
        SATURDAY("Saturday"),SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),THURSDAY("Thursday"),FRIDAY("Friday");
        
        private final String Date;
        Day(String Date){
            this.Date=Date;
        }
        
        public String getText() {
            return (Date);
        }
    }
    public Zeller(int day,int month,int year) {
        DayOfMonth = day;
        if (month<3){
            month = month + 12;
            year = year - 1;
        }
        this.month = month;
        this.year = year;
        
    }
    public String getDayOfWeed() {
        int h = (DayOfMonth+((26*(month+1))/10)+(year%100)+((year%100)/4)+((year/100)/4)+(5*(year/100)))%7;
        String text = Integer.toString(h);
    switch (h){
        case 0:
            text = Day.SATURDAY.getText();
            break;
        case 1:
            text = Day.SUNDAY.getText();
            break;
        case 2:
            text = Day.MONDAY.getText();
            break;
        case 3:
            text = Day.TUESDAY.getText();
            break;
        case 4:
            text = Day.WEDNESDAY.getText();
            break;
        case 5:
            text = Day.THURSDAY.getText();
            break;
        case 6:
            text = Day.FRIDAY.getText();
            break;
    }
    return text;
    }
    
}
