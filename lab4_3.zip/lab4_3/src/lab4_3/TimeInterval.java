/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author usci
 */
public class TimeInterval {
    private int start,end,H,m,time;
    public TimeInterval(int startTime,int endTime) {
        start = startTime;
        end = endTime;
        time = (((end/100)*60)+(end%100))-(((start/100)*60)+(start%100));
    }
    public double getHours() {
        H = time/60;
        return H;
    }
    public double getMinutes() {
        m = time%60;
        return m;
    }
}
    
