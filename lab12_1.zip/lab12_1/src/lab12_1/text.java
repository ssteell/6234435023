package lab12_1;
import java.io.*;
import java.util.Scanner; 
public class text {
    public static void main(String[] args) throws FileNotFoundException{
        PrintWriter output = new PrintWriter("out.txt");
        String input = "";
        int Char = 0;
        int words = 0;
        int line = 0;
        while(!input.equals("quit")){
            Scanner key = new Scanner(System.in);
            input = key.nextLine();
            if(!input.equals("quit")){
                line++;
                Char+=input.length();  
                if( input.length()!= 0){
                    words++;
                }
                for(int i =0 ; input.length() > i ; i++){
                    if(input.charAt(i)==' '){
                       words++;
                    }     
                }     
            
            }
        }
        System.out.println("Total characters : "+Char);
        System.out.println("Total words : "+words);
        System.out.println("Total lines : "+line);
        output.close();
    }
    
    
}