package lab8_2;

import java.util.ArrayList;

public class ChoiceQuestion extends Question{
    ArrayList<String> Choice = new ArrayList<String>();

    public ChoiceQuestion(String text) {
        super(text);
    }
    public void addChoice(String choice,boolean correct){
        Choice.add(choice);
        if(correct == true){
            super.setAnswer(+Choice.indexOf(choice)+1+"");
        }        
    }
    @Override
    public void display(){
        System.out.println(super.getText());
        for(int i = 1;i <= Choice.size();i++){
            System.out.println(i+":"+Choice.get(i-1));
        }      
    }
    @Override
    public Boolean checkAnswer(String response){
        if(response.equals(super.getAnswer()))return true;
        return false;
    }
    
}
