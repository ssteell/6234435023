package lab8_2;

public class Question {
    private String text,answer;
    public Question(String text){   
        this.text = text;
    }
    public String setText(String question){
        text = question;
        return text;
    }  
    public String setAnswer(String answer){
        this.answer = answer;
        return answer;
    }
    public String getText(){
        return text;
    } 
    public String getAnswer(){
        return answer;
    }
    public Boolean checkAnswer(String response){
        if(response.equals(answer))return true;
        return false;
    }
    public void display(){
        System.out.println(text);
    }
            
}
