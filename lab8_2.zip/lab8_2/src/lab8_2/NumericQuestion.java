package lab8_2;

public class NumericQuestion extends Question {
    public NumericQuestion(String text){
        super(text);
    }
    @Override
    public Boolean checkAnswer(String response){
        double respo = Double.parseDouble(response);
        double ans = Double.parseDouble(super.getAnswer());
        if(ans - respo < 0.01 && respo - ans < 0.01)return true;
        return false;
        
    }
    
}
