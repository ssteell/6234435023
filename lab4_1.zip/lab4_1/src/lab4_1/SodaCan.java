/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

/**
 *
 * @author usci
 */
public class SodaCan {
    private double height;
    private double diameter;
    private double volume;
    private double area;
   
    public SodaCan(double H,double D) {
        height = H;
        diameter = D;    
    }
    public double getVolume() {
        volume = (Math.PI)*((diameter/2)*(diameter/2))*height;
        return (float) volume;
        
    }
    public double getSurfaceArea() {
        area = (2*(Math.PI)*(diameter/2)*height)+(2*(Math.PI)*((diameter/2)*(diameter/2)));
        return (float) area;
    }
}
