package lab10_1;

import java.lang.reflect.Array;

public class Secretary extends Employee implements Evaluation {
    private int typingSpeed;
    private int[] score ;
    public Secretary(String name, int salary,int[] score, int typing) {
        super(name, salary);
            this.score = score;  
        typingSpeed = typing;
    }
    @Override
    public double evaluate(){
        int sum = 0;
        for(int i = 0;i < score.length;i++){
            sum += score[i];
        } 
        return sum;
    }
   @Override
   public char grade(double evaluate){
       if(evaluate >= 90){
           setSalary(18000);
           return 'P';
       }
       else{
           return 'F';
       }
   }
   
       
}
