package lab10_1;

public class Subject implements Evaluation{
    private String sudjName;
    private int score[];
    public Subject(String pass,int[] score){
        sudjName = pass;
        this.score = score;
    }
    @Override
    public double evaluate() {
        int sum = 0;
        for(int i = 0;i < score.length;i++){
            sum += score[i];
        } 
        sum = sum/score.length;
        return sum;
    }

    @Override
    public char grade(double evaluate) {
        if(evaluate >= 70){
           return 'P';
       }
       else{
           return 'F';
       }
    }
    @Override
    public String toString(){
        return sudjName;
    }
     
    
}
