/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

/**
 *
 * @author amsteel
 */
public class CityGridTester {
    public static void main(String[] args) {
        int max = 0;
        double  walk = 0;
        CityGrid test = new CityGrid(10,10);
        for (int i = 1; i <= 10000; i++){
            for (int k = 1 ; k <= 1000; k++){
                if(test.isInCity()){
                    test.walk();
                    walk++;
                }
                else{
                    test.reset();
                    if(max < k){
                        max = k;
                        
                    }
                    break;   
                }
                
            }        
        }
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f",walk/10000);
        System.out.println("\nMaximum number of steps that a person can take and is still in the city: "+max);
    }
}
