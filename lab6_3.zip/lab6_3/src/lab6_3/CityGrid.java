/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

import java.util.Random;

/**
 *
 * @author amsteel
 */
public class CityGrid {
    private int xCoor,yCoor,gridSize,x,y;
    public CityGrid(int X,int Y){
        xCoor = X/2;
        x = X;
        yCoor = Y/2;
        y = Y;
        gridSize = X*Y;
    }
    public void walk(){
        Random Walk = new Random();
        int walk = Walk.nextInt(4);
        switch(walk){
            case 0 : xCoor++;break;
            case 1 : xCoor--;break;
            case 2 : yCoor++;break;
            case 3 : yCoor--;break;
               
        }
    }
    public boolean isInCity(){
        if((xCoor < 0 || xCoor > x) || (yCoor < 0 || yCoor > y)){
            return false;
        }
        else{
            return true;
        }

    }
    public void reset() {
        xCoor = x/2;
        yCoor = y/2;

    }
}    
