/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author usci
 */
public class CannonBall {
    private double initV,simS,simT;
    public static final double g = 9.81;
    public CannonBall(double ball){
        initV = ball;
    }
    public void simulatedFlight() {
        int t = 0 ;
        int sec =1;
        double s;
        while (initV > 0) {
            
            s = initV*0.01;
            initV = initV - (g*0.01);
            simS = simS + s;
            simT = simT + 0.01;
            t++;
            
            if (t==100){
                System.out.println("Distance on "+(int)simT+" sec:"+String.format("%.3f", simS));
                t = 0;
                sec++;
            }    
        }
    }
    public double calulusFlight(double t){
       double s = (0.5)*g*Math.pow(t, 2)+initV*t;
       System.out.println("Final distance: "+String.format("%.3f", simS)+" Total time: "+String.format("%.2f", simT));
       return Math.round(s*1000)/1000.000;
    }
    public double getSimulatedTime(){
        return simT;
    }
    
}