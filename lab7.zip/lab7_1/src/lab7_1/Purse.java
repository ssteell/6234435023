/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;
import java.util.Collections;


public class Purse {
    
    private ArrayList<String> purse;
    
    public Purse(){
        purse = new ArrayList<String>(); 
    }
    public void addCoin(String coinName){
        purse.add(coinName);
    }
    public String toString(){
        String Out = "";
        for (int i = 0; i < purse.size(); i ++){
            Out += purse.get(i);
            if ( i < purse.size() - 1) Out += ",";
        }
        return Out;
    }
    public ArrayList<String> reverse(){
        ArrayList<String> purse2 = new ArrayList<String>();
        for(int i = purse.size()-1;i >= 0 ; i--){
             purse2.add(purse.get(i));
        }
        purse = purse2;
        return purse;
    }
    public void transfer(ArrayList<String> coinB, ArrayList<String> coinA){
        int x = coinA.size();
        Collections.reverse(coinA);
        Collections.reverse(coinB);
        for(int i=0; i<x;i++){
            coinB.add(coinA.get(0));
            coinA.remove(0);
        }
        System.out.println("Tranfer Purse A to Purse B: \nPurse A : "+coinA+"\nPurse B : "+coinB);
    }    
    public boolean sameContents(Purse other){
        boolean check = true;
        if(other.purse.size()!= purse.size()) check =false;
        else for (int i = 0 ; i < purse.size() ; i++){
            if (!other.purse.get(i).equals(this.purse.get(i))){
                check = false;
                break;
            } 
        }
        return check;
    }
    public boolean sameCoins(Purse other){
        boolean check = true;
        if (other.purse.size()!= purse.size()) check = false;
        else for (int i = 0 ; i < purse.size() ; i++){
            int coin1 = 0;
            int coin2 = 0;
            for (int j = 0 ; j < purse.size() ; j++){
                if (purse.get(i).equals(purse.get(j)))
                    coin1++;
                if(purse.get(i).equals(other.purse.get(j)))
                    coin2++;
            }
            if(coin1 != coin2){
                check = false;
                break;
            }
        }
        return check;
    }
}

