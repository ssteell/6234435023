/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author amsteel
 */
public class PurseTester {
    public static void main(String[] args) {
        Purse a = new Purse();
        Purse b = new Purse();
        String getCoinA ;
        String getCoinB;
        ArrayList<String> coinA = new ArrayList<String>();
        ArrayList<String> coinB = new ArrayList<String>();
        Scanner keyboard = new Scanner(System.in);
        System.out.println("If enough,put 'Enough'");
        System.out.print("Enter coin in Purse A (Penny,Nickel,Dime,Half,Quarter): ");
                getCoinA = keyboard.nextLine();
        if(!"Enough".equals(getCoinA)){
            
              do{
                if(!"Quarter".equals(getCoinA) &&  !"Dime".equals(getCoinA) && !"Nickel".equals(getCoinA) && !"Half".equals(getCoinA) && !"Penny".equals(getCoinA)&& !"Enough".equals(getCoinA)  ){
                    System.out.println("Error,re-enter");
                    System.out.print("Enter coin in Purse A (Penny,Nickel,Dime,Half,Quarter): ");
                    getCoinA = keyboard.nextLine();
           
                }else if (getCoinA != "Enough"){
                    a.addCoin(getCoinA);
                    System.out.print("Enter coin in Purse A (Penny,Nickel,Dime,Half,Quarter): ");
                    getCoinA = keyboard.nextLine();
                    
                }
                
            }while(!"Enough".equals(getCoinA) );
            System.out.print("Purse A : ");
            a.toString(); 
            System.out.println("["+a+"]");
            coinA = a.reverse();
            
            
        }
                System.out.println("If enough,put 'Enough'");
                System.out.print("Enter coin in Purse B (Penny,Nickel,Dime,Half,Quarter): ");
                getCoinB = keyboard.nextLine();
        if(!"Enough".equals(getCoinB)){
            
              do{
                if(!"Quarter".equals(getCoinB) &&  !"Dime".equals(getCoinB) && !"Nickel".equals(getCoinB) && !"Half".equals(getCoinB) && !"Penny".equals(getCoinB)&& !"Enough".equals(getCoinB)  ){
                    System.out.println("Error,re-enter");
                    System.out.print("Enter coin in Purse B (Penny,Nickel,Dime,Half,Quarter): ");
                    getCoinB = keyboard.nextLine();
           
                }else if (getCoinB != "Enough"){
                    b.addCoin(getCoinB);
                    System.out.print("Enter coin in Purse B (Penny,Nickel,Dime,Half,Quarter): ");
                    getCoinB = keyboard.nextLine();
                    
                }
                
            }while(!"Enough".equals(getCoinB) );
            System.out.print("Purse B : ");
            b.toString();  
            System.out.println("["+b+"]");
            coinB = b.reverse();
            
        }
        System.out.println("--------------------------------------------------------");
        System.out.println("Purse A : ["+a.toString()+"]");
        System.out.println("Purse B : ["+b.toString()+"]");
        b.transfer(coinB,coinA);
        System.out.println("Same coins: "+a.sameCoins(b));
        System.out.println("Same contens: "+a.sameContents(b));
    }
    
}

