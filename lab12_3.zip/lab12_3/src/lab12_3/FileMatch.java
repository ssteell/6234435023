package lab12_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

public class FileMatch {
       ArrayList<AccountRecord> accountrec = new ArrayList<>();
       ArrayList<TransactionRecord> tranrec = new ArrayList<>();
       private Double updateBalance = 0.0;
    public void addTransObject(){
         try{
           Scanner trans = new Scanner("trans.txt");
           while(trans.hasNextLine()==true){
           String ACCT = "",AMOUNT = "";
           String info  = trans.nextLine();
            for(int i =0 ; info.length()>i ; i++){
               if(info.charAt(i)!=' '){
                    ACCT+=info.charAt(i);  }
               else{
                   for(;info.length()>i+1 ; i++){
                       AMOUNT+=info.charAt(i);
                   }
                   int acctNo = Integer.parseInt(ACCT);
                   Double amount= Double.parseDouble(AMOUNT);
                   TransactionRecord object_t = new TransactionRecord(acctNo,amount);
                   tranrec.add(object_t);
                   break;
               }
               
               }
           }        
           trans.close();
           }
         catch(Exception ex){ System.out.println("Error: "+ex.getMessage());}               

    }

    public void addAccountObject() {        
        try{
           Scanner acct = new Scanner("master.txt");

           while(acct.hasNextLine()==true){
                String info  = acct.nextLine();
                String[] list = info.split(" ");
                int acctNo = Integer.parseInt(list[0]);
                Double balance= Double.parseDouble(list[3]);
                String name = list[1]+" "+list[2];
                AccountRecord a = new AccountRecord (acctNo,name,balance);
                accountrec.add(a);
            }
               acct.close();    
        }     
        catch(Exception ex){ System.out.println("Error: "+ex.getMessage());}               

    }

    public int accoutCnt() {
        int a = accountrec.size();
        return a; 
    }

    public int noTrans() {
        int no = 0;
        for(AccountRecord a : accountrec){
            for(TransactionRecord t : tranrec){
                if(a.getAcctNo()==t.getAcctNo()){
                  no++;
                  break;
                }
            }
        }
        return accountrec.size()-no ;
    }
    
    public void updateinfo(){
        RandomAccessFile rw= null;
        try{
             rw = new RandomAccessFile("/Users/family/Desktop/steel/newMaster.dat","rw");
            for(AccountRecord a : accountrec){
            for(TransactionRecord t : tranrec){
                if(a.getAcctNo()==t.getAcctNo()){
                   a.combine(t); }
            }String name=a.getName();
            for(int i = name.length(); i<30;i++){
                name+="_";
            }
            rw.write(a.getAcctNo());
            rw.writeChars(" "+name+" ");
            rw.writeDouble(a.getBalance());
            rw.writeChar('\n');
            updateBalance+=a.getBalance();
        }
            
        }catch(FileNotFoundException ex) { System.out.println("Error: "+ex.getMessage());  }        
        catch(Exception ex){ System.out.println("Error: "+ex.getMessage());}   
        finally{
            try{ if(rw!=null) rw.close();   }
            catch(IOException ex){ System.out.println("Error: "+ex.getMessage());}   
        }
        
    }
    public double updateBalance(){

        return updateBalance;
    }
}