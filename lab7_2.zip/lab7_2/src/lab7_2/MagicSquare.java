/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_2;

import java.util.Arrays;

/**
 *
 * @author amsteel
 */
public class MagicSquare {

    private int[][] square;
    private int n;
    
    
    public MagicSquare(int N){
        n=N;
        square = new int[N][N];
                
    }
    public void getNum(){
        int i = n-1;
        int j = ((n+1)/2)-1;
        square[i][j] = 1;
        for (int k = 2;k <= n*n;k++){
            if(square[(i+1)%n][(j+1)%n] != 0){
                i = (i-1)%n;
            }
            else{
                i = (i+1)%n;
                j = (j+1)%n;
            }
            square[i][j] = k;    
        }
    }
    
    public String toString(){
        String p = "";
        for (int i = 0; i < n; i++){
            p +="   ";
                for(int j = 0; j < n; j++){
                    p += square[i][j] > 9? square[i][j] + "  " :square[i][j] + "   ";
                }
            p += "\n";
        }
        return p;
     }
}

