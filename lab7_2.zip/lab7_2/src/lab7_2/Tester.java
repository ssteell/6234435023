/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_2;

import java.util.Scanner;

/**
 *
 * @author amsteel
 */
public class Tester {
public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       int N = 0;
        do{
            System.out.print("Enter odd number : ");
            N = sc.nextInt();
        }while(N%2==0);
       
       MagicSquare test = new MagicSquare(N);
       test.getNum();
       System.out.println(test.toString());
    }
}
